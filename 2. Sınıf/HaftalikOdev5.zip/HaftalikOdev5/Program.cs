﻿
//Main methodu kullanmıyorum
public class Program
{
    public static void Main()
    {

    }
}