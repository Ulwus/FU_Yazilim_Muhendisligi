﻿namespace HaftalikOdev5.UML2
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}