﻿using System.Reflection.PortableExecutable;

namespace HaftalikOdev5.UML2
{
    public class PetInformation
    {
        public List<string> Traits { get; set; }
        public List<Vaccine> Vaccines { get; set; }
    }
}