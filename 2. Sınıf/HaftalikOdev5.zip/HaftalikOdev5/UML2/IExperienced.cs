﻿namespace HaftalikOdev5.UML2
{
    public interface IExperienced
    {
    }
}