﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaftalikOdev5.UML2
{
    public class Owner : IExperienced
    {
        public string Name { get; set; }
    }

}
