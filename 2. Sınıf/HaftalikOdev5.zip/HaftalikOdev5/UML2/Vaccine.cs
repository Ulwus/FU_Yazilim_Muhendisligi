﻿namespace HaftalikOdev5.UML2
{
    public class Vaccine
    {
        public string Name { get; set; }
        public string Type { get; set; }
    }
}