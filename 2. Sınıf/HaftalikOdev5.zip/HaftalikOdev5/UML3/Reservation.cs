﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaftalikOdev5.UML3
{
    public class Reservation
    {
        public int Id { get; set; }
        public string Details { get; set; }
        public string List { get; set; }

        public void Confirmation() { }
    }
}
