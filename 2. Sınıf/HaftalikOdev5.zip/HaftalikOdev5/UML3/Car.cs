﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HaftalikOdev5.UML3
{
    public class Car
    {
        public int Id { get; set; }
        public int Details { get; set; }
        public string OrderType { get; set; }

        public void ProcessDebit() { }
    }
}
